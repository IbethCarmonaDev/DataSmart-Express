
import streamlit as st
import pandas as pd
import os
from core.estado_resultados import generar_estado_resultados_detallado, generar_estado_resultados_todos_los_meses
from core.exportador import exportar_a_excel
from core.analisis_presentacion import generar_html_estado_resultados, generar_html_tarjetas, mostrar_mensaje_plan
from core.analisis_avanzado import generar_conclusiones_avanzadas, generar_tabla_comparativa_html
from core.analisis_lenguaje import generar_conclusiones

st.set_page_config(layout="wide")
st.image("logo.png", width=200)
st.title("DataSmart Express")

archivo_usuario = st.file_uploader("📂 Carga tu archivo de datos y parámetros (Excel)", type=["xlsx"])

if archivo_usuario:
    try:
        df_datos = pd.read_excel(archivo_usuario, sheet_name="DATOS_FINANCIEROS")
        df_clasificacion = pd.read_excel(archivo_usuario, sheet_name="CLASIFICACION_CUENTAS", dtype={"PREFIJO": str})
        df_clasificacion.columns = df_clasificacion.columns.str.strip().str.upper()
    except Exception as e:
        st.error(f"❌ Error al leer el archivo del usuario: {e}")
        st.stop()

    try:
        archivo_parametros = "Parametros.xlsx"
        df_tarjetas_config = pd.read_excel(archivo_parametros, sheet_name="TARJETAS")
        df_kpis_config = pd.read_excel(archivo_parametros, sheet_name="KPIS_FINANCIEROS")
        df_planes = pd.read_excel(archivo_parametros, sheet_name="PLANES")
        df_planes.set_index("FUNCIONALIDAD", inplace=True)
    except Exception as e:
        st.warning(f"⚠️ No se pudo cargar la configuración de parámetros: {e}")
        df_planes = pd.DataFrame()

    # Validación de columnas
    if "AÑO" not in df_datos.columns or "MES" not in df_datos.columns:
        st.error("❌ El archivo debe contener las columnas 'AÑO' y 'MES'.")
        st.stop()

    # Convertir mes numérico a nombre si es necesario
    meses_map = {1: "Enero", 2: "Febrero", 3: "Marzo", 4: "Abril", 5: "Mayo", 6: "Junio",
                 7: "Julio", 8: "Agosto", 9: "Septiembre", 10: "Octubre", 11: "Noviembre", 12: "Diciembre"}
    df_datos["MES_NOMBRE"] = df_datos["MES"].map(meses_map)

    año = st.selectbox("1⃣ Selecciona el año", sorted(df_datos["AÑO"].dropna().unique(), reverse=True))
    mes_nombre = st.selectbox("2⃣ Selecciona el mes", df_datos["MES_NOMBRE"].dropna().unique())
    mes = [k for k, v in meses_map.items() if v == mes_nombre][0]

    if "CENTRO_COSTO" in df_datos.columns:
        opciones_cc = ["TODOS"] + sorted(df_datos["CENTRO_COSTO"].dropna().unique())
        centro = st.selectbox("3⃣ Selecciona centro de costos (opcional)", opciones_cc)
    else:
        centro = "TODOS"

    st.markdown("---")

    df_estado, df_kpis = generar_estado_resultados_detallado(df_datos, df_clasificacion, df_tarjetas_config, df_kpis_config, año, mes, centro)
    html_estado = generar_html_estado_resultados(df_estado)
    html_tarjetas = generar_html_tarjetas(df_kpis)
    st.markdown(html_tarjetas, unsafe_allow_html=True)
    st.markdown(html_estado, unsafe_allow_html=True)

    st.markdown("---")
    st.subheader("🧠 Conclusiones en lenguaje natural")
    for c in generar_conclusiones(df_estado):
        st.write("- ", c)

    st.markdown("---")
    if st.button("📥 Exportar a Excel"):
        exportar_a_excel(df_estado, df_kpis)

    mostrar_mensaje_plan("exportar", df_planes)

    st.markdown("---")
    st.subheader("📊 Análisis Avanzado")
    tabla_comparativa = generar_tabla_comparativa_html(df_kpis)
    st.markdown(tabla_comparativa, unsafe_allow_html=True)
    for c in generar_conclusiones_avanzadas(df_kpis):
        st.write("- ", c)

else:
    st.info("Por favor, sube un archivo para comenzar.")
